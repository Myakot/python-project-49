from brain_games import cli, engine
from brain_games.engine import counter

def current_correct_answer(question):
    if question % 2 == 0:
        return 'yes'
    else:
        return 'no'


def main():
    print('Answer "yes" if the number is even, otherwise answer "no".')
    user_name = cli.welcome_get_name()
    attempt = counter
    while attempt < 3:
        question = engine.get_initial_randomized_number()
        answer = current_correct_answer(question)
        print(f'Question: is {question} even?')
        user_answer = cli.getting_user_answer()
        engine.engine_main(answer, user_answer, user_name)
        print('DEBUG:---FUNCTION CAME BACK TO ENGINE_EVEN---')


# if __name__ == "__main__":
#     main()