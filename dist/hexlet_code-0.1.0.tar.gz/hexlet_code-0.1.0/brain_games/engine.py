from brain_games import cli
from random import randint


counter = 0


def get_initial_randomized_number():
    return randint(1, 10)


def engine_main(correct_answer, user_answer, user_name):
    if correct_answer == user_answer:
        print("Correct!\n")
        counter += 1
    else:
        cli.show_correct_answer(user_answer, correct_answer, user_name)

    if counter == 3:
        cli.return_win_end(user_name)
    return counter
