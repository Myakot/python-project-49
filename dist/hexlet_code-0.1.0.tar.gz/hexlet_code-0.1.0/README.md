### Hexlet tests and linter status:
[![Actions Status](https://github.com/Myakot/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/Myakot/python-project-49/actions)
[![Maintainability](https://api.codeclimate.com/v1/badges/b59cde75c1a789a2b933/maintainability)](https://codeclimate.com/github/Myakot/python-project-49/maintainability)

brain_even.py - https://asciinema.org/a/5yVjkBxYDkc3L5OAfVjGYINEk
